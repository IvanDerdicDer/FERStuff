let arr = [];
if(!window.localStorage.lista){
    window.localStorage.setItem("lista", arr);
}
if(!window.localStorage.broj){
    window.localStorage.setItem("broj", 0)
}